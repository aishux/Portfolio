from django.shortcuts import render
from .models import Projects,Certifications
from django.contrib import messages

# Create your views here.

def projectsHome(request):
    top_projs = Projects.objects.filter(is_top=True)
    other_projs = Projects.objects.filter(is_top=False)
    return render(request,'projects/projects.html',{'top_projs':top_projs,"other_projs":other_projs})

def projectView(request,id):
    project = Projects.objects.filter(project_id=id)[0]
    return render(request,'projects/projectView.html',{'project':project})

def certifications(request):
    all_certi =  Certifications.objects.all()
    return render(request,'projects/certifications.html',{'all_certi':all_certi})